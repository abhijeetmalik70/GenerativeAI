def sort_age(lst):
    return lst.sort(key = lambda x: x[1], reverse = True)
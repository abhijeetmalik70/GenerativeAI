def top_k(lst, k):
    list = []
    while len(lst) < k:
        a = max(lst)
        lst.remove(a)
        new.append(a)
    return list
